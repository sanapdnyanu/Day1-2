# Employee Management CLI
# Features: Add, Update, Delete, Search, List, Highest Salary,
# Average Salary, and Department Filter.

employees = []

def add_employee():
    emp_id = input("Enter employee ID: ")
    if any(e["id"] == emp_id for e in employees):
        print("Employee ID already exists.")
        return

    name = input("Enter name: ")
    age = int(input("Enter age: "))
    department = input("Enter department: ")
    salary = float(input("Enter salary: "))

    employees.append({
        "id": emp_id,
        "name": name,
        "age": age,
        "department": department,
        "salary": salary
    })
    print("Employee added successfully.")

def update_employee():
    emp_id = input("Enter employee ID to update: ")
    employee = next((e for e in employees if e["id"] == emp_id), None)

    if employee is None:
        print("Employee not found.")
        return

    employee["name"] = input(f"Name [{employee['name']}]: ") or employee["name"]
    age = input(f"Age [{employee['age']}]: ")
    department = input(f"Department [{employee['department']}]: ")
    salary = input(f"Salary [{employee['salary']}]: ")

    if age:
        employee["age"] = int(age)
    if department:
        employee["department"] = department
    if salary:
        employee["salary"] = float(salary)

    print("Employee updated successfully.")

def delete_employee():
    emp_id = input("Enter employee ID to delete: ")
    for employee in employees:
        if employee["id"] == emp_id:
            employees.remove(employee)
            print("Employee deleted successfully.")
            return
    print("Employee not found.")

def search_employee():
    keyword = input("Enter employee ID or name: ").lower()
    results = [
        e for e in employees
        if keyword in e["id"].lower() or keyword in e["name"].lower()
    ]
    display_employees(results)

def list_employees():
    display_employees(employees)

def display_employees(records):
    if not records:
        print("No employees found.")
        return

    print("\n" + "-" * 75)
    print(f"{'ID':<10}{'Name':<20}{'Age':<8}{'Department':<17}{'Salary':>12}")
    print("-" * 75)

    for e in records:
        print(f"{e['id']:<10}{e['name']:<20}{e['age']:<8}"
              f"{e['department']:<17}{e['salary']:>12.2f}")

    print("-" * 75)

def highest_salary():
    if not employees:
        print("No employees available.")
        return
    employee = max(employees, key=lambda e: e["salary"])
    print(f"Highest salary: {employee['name']} - ₹{employee['salary']:.2f}")

def average_salary():
    if not employees:
        print("No employees available.")
        return
    average = sum(e["salary"] for e in employees) / len(employees)
    print(f"Average salary: ₹{average:.2f}")

def department_filter():
    department = input("Enter department: ").lower()
    results = [
        e for e in employees
        if e["department"].lower() == department
    ]
    display_employees(results)

def main():
    while True:
        print("""
===== Employee Management System =====
1. Add Employee
2. Update Employee
3. Delete Employee
4. Search Employee
5. List Employees
6. Highest Salary
7. Average Salary
8. Department Filter
9. Exit
""")
        choice = input("Enter your choice: ")

        try:
            if choice == "1":
                add_employee()
            elif choice == "2":
                update_employee()
            elif choice == "3":
                delete_employee()
            elif choice == "4":
                search_employee()
            elif choice == "5":
                list_employees()
            elif choice == "6":
                highest_salary()
            elif choice == "7":
                average_salary()
            elif choice == "8":
                department_filter()
            elif choice == "9":
                print("Program ended.")
                break
            else:
                print("Invalid choice. Please try again.")
        except ValueError:
            print("Please enter valid numeric values for age and salary.")

if __name__ == "__main__":
    main()
