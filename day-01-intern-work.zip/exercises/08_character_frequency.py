# 8. Character Frequency
text = input("Enter a string: ")
frequency = {}
for char in text:
    frequency[char] = frequency.get(char, 0) + 1
print("Character frequency:", frequency)
