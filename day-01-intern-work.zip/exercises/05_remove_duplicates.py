# 5. Remove Duplicates
numbers = list(map(int, input("Enter numbers separated by spaces: ").split()))
result = list(dict.fromkeys(numbers))
print("Without duplicates:", result)
