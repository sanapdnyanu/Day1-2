# 13. Queue Implementation
from collections import deque

queue = deque()

while True:
    print("\n1. Enqueue  2. Dequeue  3. Display  4. Exit")
    choice = input("Enter choice: ")
    if choice == "1":
        queue.append(input("Enter value: "))
    elif choice == "2":
        if queue:
            print("Dequeued:", queue.popleft())
        else:
            print("Queue is empty.")
    elif choice == "3":
        print("Queue:", list(queue))
    elif choice == "4":
        break
    else:
        print("Invalid choice.")
