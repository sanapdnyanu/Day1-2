# 6. Find Missing Number
numbers = list(map(int, input("Enter numbers from 1 to n with one missing: ").split()))
n = len(numbers) + 1
expected = n * (n + 1) // 2
print("Missing number:", expected - sum(numbers))
