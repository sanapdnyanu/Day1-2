# 14. Maximum Subarray Sum (Kadane's Algorithm)
numbers = list(map(int, input("Enter numbers: ").split()))
if not numbers:
    print("No numbers entered.")
else:
    current = best = numbers[0]
    for number in numbers[1:]:
        current = max(number, current + number)
        best = max(best, current)
    print("Maximum subarray sum:", best)
