# 4. Find Second-Largest Number
numbers = list(map(int, input("Enter numbers separated by spaces: ").split()))
unique = list(set(numbers))
if len(unique) < 2:
    print("Need at least two different numbers.")
else:
    unique.sort(reverse=True)
    print("Second largest:", unique[1])
