# 7. Find Duplicate Number
numbers = list(map(int, input("Enter numbers: ").split()))
seen = set()
duplicates = []
for number in numbers:
    if number in seen and number not in duplicates:
        duplicates.append(number)
    seen.add(number)
print("Duplicate number(s):", duplicates)
