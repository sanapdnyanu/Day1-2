# 3. Find Largest Number
numbers = list(map(int, input("Enter numbers separated by spaces: ").split()))
print("Largest:", max(numbers))
