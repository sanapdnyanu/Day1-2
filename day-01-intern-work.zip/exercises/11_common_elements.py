# 11. Find Common Elements
a = list(map(int, input("Enter first list: ").split()))
b = list(map(int, input("Enter second list: ").split()))
common = list(dict.fromkeys(x for x in a if x in b))
print("Common elements:", common)
