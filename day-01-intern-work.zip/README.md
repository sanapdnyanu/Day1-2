# Day 1 - Programming Fundamentals

This folder contains the Day 1 practical work from the 10-Day Intern Technical Training program.

## Contents

### 15 Programming Exercises
1. Reverse a string
2. Check palindrome
3. Find largest number
4. Find second-largest number
5. Remove duplicates
6. Find missing number
7. Find duplicate number
8. Character frequency
9. First non-repeating character
10. Merge two sorted arrays
11. Common elements
12. Stack
13. Queue
14. Maximum subarray sum
15. Sorting without built-in sort()

### Employee Management CLI

Features:
- Add Employee
- Update Employee
- Delete Employee
- Search Employee
- List Employees
- Highest Salary
- Average Salary
- Department Filter

## How to Run

Open a terminal in this folder.

Run an exercise:
```bash
python exercises/01_reverse_string.py
```

Run the employee management system:
```bash
python employee-management/employee_management.py
```

## Git

After testing:
```bash
git add .
git commit -m "Complete Day 1 programming exercises and employee management"
git push
```
