import json
from pathlib import Path

DATA_FILE = Path("employees.json")


def load_data():
    if not DATA_FILE.exists():
        return []

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return []


def save_data(employees):
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(employees, file, indent=4)


def add_employee(employees):
    employee_id = input("Enter Employee ID: ").strip()

    if any(emp["id"] == employee_id for emp in employees):
        print("Employee ID already exists.")
        return

    name = input("Enter Name: ").strip()
    department = input("Enter Department: ").strip()

    try:
        age = int(input("Enter Age: "))
        salary = float(input("Enter Salary: "))
    except ValueError:
        print("Age must be an integer and salary must be a number.")
        return

    employees.append({
        "id": employee_id,
        "name": name,
        "age": age,
        "department": department,
        "salary": salary
    })

    save_data(employees)
    print("Employee added successfully.")


def update_employee(employees):
    employee_id = input("Enter Employee ID to update: ").strip()

    for emp in employees:
        if emp["id"] == employee_id:
            print("Press Enter to keep the old value.")

            name = input(f"Name [{emp['name']}]: ").strip()
            department = input(f"Department [{emp['department']}]: ").strip()
            age = input(f"Age [{emp['age']}]: ").strip()
            salary = input(f"Salary [{emp['salary']}]: ").strip()

            if name:
                emp["name"] = name
            if department:
                emp["department"] = department

            if age:
                try:
                    emp["age"] = int(age)
                except ValueError:
                    print("Invalid age. Old age kept.")

            if salary:
                try:
                    emp["salary"] = float(salary)
                except ValueError:
                    print("Invalid salary. Old salary kept.")

            save_data(employees)
            print("Employee updated successfully.")
            return

    print("Employee not found.")


def delete_employee(employees):
    employee_id = input("Enter Employee ID to delete: ").strip()

    for emp in employees:
        if emp["id"] == employee_id:
            employees.remove(emp)
            save_data(employees)
            print("Employee deleted successfully.")
            return

    print("Employee not found.")


def search_employee(employees):
    keyword = input("Enter Employee ID or Name: ").strip().lower()

    results = [
        emp for emp in employees
        if keyword in emp["id"].lower()
        or keyword in emp["name"].lower()
    ]

    if not results:
        print("No employee found.")
        return

    display_employees(results)


def filter_by_department(employees):
    department = input("Enter Department: ").strip().lower()

    results = [
        emp for emp in employees
        if emp["department"].lower() == department
    ]

    if not results:
        print("No employees found in this department.")
        return

    display_employees(results)


def sort_employees(employees):
    print("\n1. Sort by Name")
    print("2. Sort by Salary")
    print("3. Sort by Age")

    choice = input("Choose option: ").strip()

    if choice == "1":
        results = sorted(employees, key=lambda emp: emp["name"].lower())
    elif choice == "2":
        results = sorted(employees, key=lambda emp: emp["salary"])
    elif choice == "3":
        results = sorted(employees, key=lambda emp: emp["age"])
    else:
        print("Invalid choice.")
        return

    display_employees(results)


def show_statistics(employees):
    if not employees:
        print("No employee data available.")
        return

    total = len(employees)
    average_salary = sum(emp["salary"] for emp in employees) / total
    highest = max(employees, key=lambda emp: emp["salary"])
    lowest = min(employees, key=lambda emp: emp["salary"])

    departments = {}
    for emp in employees:
        departments[emp["department"]] = departments.get(emp["department"], 0) + 1

    print("\n--- Statistics ---")
    print("Total Employees:", total)
    print(f"Average Salary: {average_salary:.2f}")
    print(f"Highest Salary: {highest['name']} - {highest['salary']:.2f}")
    print(f"Lowest Salary: {lowest['name']} - {lowest['salary']:.2f}")

    print("\nEmployees by Department:")
    for department, count in departments.items():
        print(f"{department}: {count}")


def display_employees(employees):
    print("\n" + "-" * 75)
    print(f"{'ID':<10}{'Name':<20}{'Age':<8}{'Department':<20}{'Salary':>12}")
    print("-" * 75)

    for emp in employees:
        print(
            f"{emp['id']:<10}"
            f"{emp['name']:<20}"
            f"{emp['age']:<8}"
            f"{emp['department']:<20}"
            f"{emp['salary']:>12.2f}"
        )

    print("-" * 75)


def main():
    employees = load_data()

    while True:
        print("\n===== Python Management System =====")
        print("1. Add Employee")
        print("2. Update Employee")
        print("3. Delete Employee")
        print("4. Search Employee")
        print("5. Filter by Department")
        print("6. Sort Employees")
        print("7. Show Statistics")
        print("8. List All Employees")
        print("9. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            add_employee(employees)
        elif choice == "2":
            update_employee(employees)
        elif choice == "3":
            delete_employee(employees)
        elif choice == "4":
            search_employee(employees)
        elif choice == "5":
            filter_by_department(employees)
        elif choice == "6":
            sort_employees(employees)
        elif choice == "7":
            show_statistics(employees)
        elif choice == "8":
            if employees:
                display_employees(employees)
            else:
                print("No employee data available.")
        elif choice == "9":
            print("Thank you for using the Management System.")
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
