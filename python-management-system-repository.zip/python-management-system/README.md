# Python Management System

A simple Python Management System for managing employee records.

## Features

- Add employee
- Update employee
- Delete employee
- Search employee
- Filter by department
- Sort by name, salary, or age
- Show statistics
- List all employees
- Save data permanently in JSON

## Technologies

- Python
- JSON
- Python standard library

## How to Run

1. Open this folder in VS Code.
2. Open the terminal.
3. Run:

```bash
python management_system.py
```

If `python` does not work on Windows, try:

```bash
py management_system.py
```

The program automatically creates `employees.json` when you add the first employee.

## Project Structure

```text
python-management-system/
├── management_system.py
├── employees.json
└── README.md
```

## Example Data

The `employees.json` file contains sample employee records. You can delete the sample records if you want to start with an empty database.

## GitHub

After testing the project, create a Git repository and push these files to GitHub.
